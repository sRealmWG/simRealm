int No_of_SPECIES;
int No_of_COLUMNS;
int No_of_TRANSECTS;
int REPLICATES;
double Colonization_Rate;
double Extinction_Rate;
double Detectability_Value;
double Phi_0; // Probability of presence at time 0.
int RATES;
/* Parameter Symbols */
char ** Symbol;
