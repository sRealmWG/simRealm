  int No_of_PARAMETERS; /* No of parameters defining the actual dimension of 
			   the subparameter space */

  int I0, I1, I2, I3, I4, I5, I6, I7, I8, I9;  
  int d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;  
  double MAX_P0, MAX_P1, MAX_P2, MAX_P3, MAX_P4, MAX_P5, MAX_P6, MAX_P7, MAX_P8, MAX_P9;
  double min_P0, min_P1, min_P2, min_P3, min_P4, min_P5, min_P6, min_P7, min_P8, min_P9;
  double Acc_P0, Acc_P1, Acc_P2, Acc_P3, Acc_P4, Acc_P5, Acc_P6, Acc_P7, Acc_P8, Acc_P9; 

  double TOLERANCE;
  int MAX_No_of_ITERATIONS; 
