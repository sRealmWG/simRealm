typedef struct Parameter_Fittinginfo
{
  SP_Matrix_Data * Data;
  Parameter_Model * P;
  Parameter_Space * Space;
  int Verbose; 

}Parameter_Fitting;
